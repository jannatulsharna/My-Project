@extends('layouts/login_homepage')
@section('body')
	<h1 style="text-align: center;">Welcome To our service</h1>
	<hr>
	<br>
	<ul style="padding-left:40px;">
		<li><a href="#">See our Branch</a></li>
		<li><a href="#">Request for courier a parcel</a></li>
		<li><a href="#">view your profile</a></li>
		<li><a href="#">About us</a></li>
		<li><a href="/">log out</a></li>
	</ul>
@endsection