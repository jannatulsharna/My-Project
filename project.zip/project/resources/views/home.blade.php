@extends('layouts.homepage')

@section('body')
<h1>Welcome to our website</h1>
<h2>Nagin dance</h2>

@endsection



