<?php $__env->startSection('body'); ?>
	<h1 style="text-align: center;">Welcome To our service</h1>
	<hr>
	<br>
	<ul style="padding-left:40px;">
		<li><a href="#">See our Branch</a></li>
		<li><a href="#">Request for courier a parcel</a></li>
		<li><a href="#">view your profile</a></li>
		<li><a href="#">About us</a></li>
		<li><a href="/">log out</a></li>
	</ul>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts/login_homepage', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\XAMPP\htdocs\project\resources\views/CustomerHomepage.blade.php ENDPATH**/ ?>