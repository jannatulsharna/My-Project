<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class FirstController extends Controller
{
    public function index(){

    	echo" My First Project";
    } 
     public function homepage(){

    	return view('home');
    }
}
